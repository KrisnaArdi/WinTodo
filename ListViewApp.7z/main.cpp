#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <vector>
#include <fstream>
#include "resource1.h"
#include "resource.h"
#include "listview.h"

//using visual styles
#pragma comment(linker,"\"/manifestdependency:type='win32' name='Microsoft.Windows.Common-Controls' version = '6.0.0.0' processorArchitecture = '*' publicKeyToken = '6595b64144ccf1df' language = '*'\"")

wchar_t ClassName[] = L"WindowClass";
std::vector<Task> TaskList;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain(HINSTANCE hins, HINSTANCE hprev, LPSTR lpcmd, int ncmd) {
	WNDCLASSEX wc;
	HWND hwnd;
	MSG msg;

	memset(&wc, 0, sizeof(wc));

	wc.cbSize = sizeof(wc);
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hins;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW);
	wc.lpszMenuName = MAKEINTRESOURCE(IDR_MENU1);
	wc.lpszClassName = ClassName;

	if (!RegisterClassEx(&wc)) {
		MessageBox(NULL, L"Window Registration Failed!", L"Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	hwnd = CreateWindowEx(WS_EX_CLIENTEDGE,
		ClassName, L"MyTodo", WS_VISIBLE | WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, 521, 480,
		NULL, NULL, hins, NULL);

	if (hwnd == NULL) {
		MessageBox(NULL, L"Window Creation Failed!", L"Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	while (GetMessage(&msg, NULL, 0, 0) > 0) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}


LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {

	HWND  edit, AddBtn, lview, delBtn, delAllBtn, delFin, delUnFin;
	LVITEM lvi;
	RECT rc;

	switch (msg) {
	case WM_CLOSE: {
		int confirm = MessageBox(NULL, L"Save Changes to the list?", L"Alert!", MB_ICONINFORMATION | MB_YESNOCANCEL);
		if (confirm == IDYES) {
			WriteTaskToFile(TaskList); //saving changes before closing files
			PostQuitMessage(0);
		}
		else if (confirm == IDNO) {
			PostQuitMessage(0);
		}
		else if (confirm == IDCANCEL) { break; }
		break;
	}
		
	case WM_CREATE: {
		GetClientRect(hwnd, &rc);
		int btnY = rc.bottom - btnH;

		lview = CreateListView(hwnd, LVIEW);

		edit = CreateWindow(L"EDIT", L"",
			WS_VISIBLE | WS_CHILD | WS_BORDER,
			0, 0, rc.right - 102, btnH,
			hwnd, (HMENU)ID_INPUT, NULL, NULL);

		AddBtn = CreateWindow(L"BUTTON", L"Add item",
			WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON | BS_USERBUTTON,
			rc.right - btnW, 0, btnW, btnH,
			hwnd, (HMENU)ID_ADD, NULL, NULL);

		delBtn = CreateWindow(L"Button", L"Delete",
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			0, btnY, btnW, btnH, hwnd, (HMENU)ID_DEL, NULL, NULL);

		delAllBtn = CreateWindow(L"Button", L"Delete all",
			WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
			btnW, btnY, btnW, btnH, hwnd, (HMENU)ID_DELALL, NULL, NULL);

		delFin = CreateWindow(L"Button", L"Delete finished",
			WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
			(2 * btnW), btnY, btnW, btnH, hwnd, (HMENU)ID_DELFIN, NULL, NULL);

		delUnFin = CreateWindow(L"Button", L"Delete unfinished",
			WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
			(3 * btnW), btnY, btnW, btnH, hwnd, (HMENU)ID_DELUNFIN, NULL, NULL);


		/*Setting Font */
		HWND buttons[5] = { AddBtn, delBtn, delAllBtn, delFin, delUnFin }; //all button control
		for (int i = 0; i < 5; ++i) { //set font for all button control
			SendMessage(buttons[i], WM_SETFONT, (WPARAM)BtnFont, TRUE);
		}
		SendMessage(edit, WM_SETFONT, (WPARAM)EditFont, TRUE); //edit font
		SendMessage(lview, WM_SETFONT, (WPARAM)LviewFont, TRUE); //listview font

		SendMessage(edit, EM_SETCUEBANNER, 0, LPARAM(L"Add a new item here")); //setting placeholder for edit 
		LoadTaskFromFile(&TaskList, lview); //loading task from file
		renderTask(TaskList, lview); //render the task
		break;
	}
	case WM_NOTIFY: {
		switch (LOWORD(wparam)) {
		case LVIEW: {
			lview = GetDlgItem(hwnd, LVIEW);
			LPNMLISTVIEW pnm = (LPNMLISTVIEW)lparam;
			//processing custom draw
			if (pnm->hdr.hwndFrom == lview && pnm->hdr.code == NM_CUSTOMDRAW) {
				//return LRESULT of custom draw function
				return ProcessCustomDraw(lparam, TaskList);
			}

			if (((LPNMHDR)lparam)->code == NM_CLICK ) {
				iSelect = SendMessage(lview, LVM_GETNEXTITEM, -1, LVNI_FOCUSED);
				if(iSelect == -1)break;
				selectFlag = 1;
				}
			
				//this is to process the checkbox message
				if(pnm->uChanged & LVIF_STATE) {
					switch (pnm->uNewState)
					{
					case INDEXTOSTATEIMAGEMASK(2):
						// item was checked
	
						TaskList[pnm->iItem].status = 1; //change status in the vector

						//this function only changing the text in status column
						toggleTaskStatus(lview, pnm->iItem, 1);
						break;
					case INDEXTOSTATEIMAGEMASK(1):
						//item was unchecked
						TaskList[pnm->iItem].status = 0;
						toggleTaskStatus(lview, pnm->iItem, 0);
						break;
					}
				}
			}
			break;
		}
		break;
	}
	case WM_COMMAND: {
		switch (LOWORD(wparam)) {
		case ID_ADD: {
			edit = GetDlgItem(hwnd, ID_INPUT);
			lview = GetDlgItem(hwnd, LVIEW);
			wchar_t pszText[256];
			int iItem;
			
			GetDlgItemText(hwnd, ID_INPUT, pszText, 256); //get the text from input
			
			//return an error if the input is blank
			if (pszText[0] == 0) {
				MessageBox(NULL, L"You cannot create an empty task!", L"Information", MB_ICONERROR | MB_OK);
				break;
			}

			//create a new Task class and insert it to the vector
			Task newTask;
			wcscpy_s(newTask.name, pszText);
			newTask.status = 0; //status is absolutely unfinished 
			TaskList.push_back(newTask);

			iItem = SendMessage(lview, LVM_GETITEMCOUNT, 0, 0); //get number of listview item
			lvi.mask = LVIF_TEXT;
			lvi.iItem = iItem;
			lvi.iSubItem = 0;
			lvi.pszText = pszText;
			ListView_InsertItem(lview, &lvi);

			lvi.iItem = iItem;
			lvi.iSubItem = 1;
			lvi.pszText = L"Unfinished";
			ListView_SetItem(lview, &lvi);

			SetDlgItemText(hwnd, ID_INPUT, L"");
			SetFocus(edit); //focus to edit control
			}
			break;
			
		case ID_DEL: {
			lview = GetDlgItem(hwnd, LVIEW);
			//if an item is selected
			if (selectFlag) {
				SendMessage(lview, LVM_DELETEITEM, iSelect, 0); //delete the task from the listview
				TaskList.erase(TaskList.begin() + iSelect); //delete the task from the vector
				selectFlag = 0; //not selecting any item
				}
			else MessageBox(NULL, L"Select item first before delete it by clicking the item!",L"Information", MB_ICONINFORMATION | MB_OK);
			}
			break;
		case ID_DELALL: {
			lview = GetDlgItem(hwnd, LVIEW);
			int iItem = SendMessage(lview, LVM_GETITEMCOUNT, 0, 0);
			
			if (iItem == 0) {
				MessageBox(NULL, L"There is no item!", L"", MB_ICONINFORMATION | MB_OK);
				break;
			}
			
			//make a convirmation box
			int confirm = MessageBox(NULL, L"You are about to delete all task items, are you sure?", L"Confirmation", MB_ICONINFORMATION | MB_YESNO);
			//user press yes
			if (confirm == IDYES) {
				SendMessage(lview, LVM_DELETEALLITEMS, 0, 0);
				TaskList.clear();
				MessageBox(NULL, L"All items has been deleted", L"Information", MB_ICONINFORMATION | MB_OK);
				}
			//user press no
			if (confirm == IDNO) {
				break;
			}
			}
			break;
		case ID_DELFIN: {
			lview = GetDlgItem(hwnd, LVIEW);
			int i = 0;
			std::vector<int> tmp; //this is a vector of finished item index number
			
			wchar_t buff[16];
			wchar_t msg[256];
			wcscpy(msg, L"All finished item is about to be deleted");
			int confirm = MessageBox(NULL, msg , L"Information", MB_ICONINFORMATION |MB_OKCANCEL);
			if (confirm == IDOK) {
				for (std::vector<Task>::iterator it = TaskList.begin(); it != TaskList.end(); ++it) {
					if (it->status) { tmp.push_back(i); }  //put item index number if finished
					++i;
					}

				for (unsigned j = tmp.size(); j-- > 0; ) { //use reverse loop to avoid error when deleting later items	
					TaskList.erase(TaskList.begin() + tmp[j]);
					SendMessage(lview, LVM_DELETEITEM, tmp[j], 0);
					}
				MessageBox(NULL, L"All finished items has been deleted", L"Information", MB_ICONINFORMATION | MB_OK);
				}
			}
			break;
		case ID_DELUNFIN: {
			//this one has only few changes compared to delfin
			lview = GetDlgItem(hwnd, LVIEW);
			int i = 0;
			std::vector<int> tmp; //vector of unfinished item index number

			wchar_t buff[16];
			wchar_t msg[256];
			wcscpy(msg, L"All unfinished item is about to be deleted");
			int confirm = MessageBox(NULL, msg, L"Information", MB_ICONINFORMATION | MB_OKCANCEL);
			if (confirm == IDOK) {
				for (std::vector<Task>::iterator it = TaskList.begin(); it != TaskList.end(); ++it) {
					if (!it->status) { tmp.push_back(i); }  //put item index number if unfinished
					++i;
					}

				for (unsigned j = tmp.size(); j-- > 0; ) { //use reverse loop to avoid error when deleting later items	
					TaskList.erase(TaskList.begin() + tmp[j]);
					SendMessage(lview, LVM_DELETEITEM, tmp[j], 0);
					}
				MessageBox(NULL, L"All unfinished items has been deleted", L"Information", MB_ICONINFORMATION | MB_OK);
				}
			}
			break;
		case ID_FILE_SAVECHANGES: {
			WriteTaskToFile(TaskList);
			MessageBox(NULL, L"Changes saved!", L"Information", MB_ICONINFORMATION | MB_OK);
			}
		}
		case ID_FILE_EXIT: {
			PostMessage(hwnd, WM_CLOSE, 0, 0);
		}
		break;
	}
	case WM_SIZE: {
		edit = GetDlgItem(hwnd, ID_INPUT);
		AddBtn = GetDlgItem(hwnd, ID_ADD);
		lview = GetDlgItem(hwnd, LVIEW);
		delBtn = GetDlgItem(hwnd, ID_DEL);
		delAllBtn = GetDlgItem(hwnd, ID_DELALL);
		delFin = GetDlgItem(hwnd, ID_DELFIN);
		delUnFin = GetDlgItem(hwnd, ID_DELUNFIN);

		GetClientRect(hwnd, &rc); //getting the client of the hwnd
		int btnY = rc.bottom - btnH;

		SetWindowPos(edit, 0, 0, 0, rc.right - btnW, btnH, SWP_NOZORDER); //resize the input
		SetWindowPos(AddBtn, 0, rc.right - btnW, 0, btnW, btnH, SWP_NOZORDER | SWP_NOSIZE); //resize the button
		SetWindowPos(lview, 0, 0, btnH, rc.right, rc.bottom - (2 * btnH), SWP_NOZORDER); //resize the listview
		SetWindowPos(delBtn, 0, 0, btnY, btnW, btnH, SWP_NOZORDER | SWP_NOSIZE); //resize the delete button
		SetWindowPos(delAllBtn, 0, btnW, btnY, btnW, btnH, SWP_NOZORDER | SWP_NOSIZE); //resize the delete all button
		SetWindowPos(delFin, 0, (2*btnW), btnY, btnW, btnH, SWP_NOZORDER | SWP_NOSIZE); //delete finished button
		SetWindowPos(delUnFin, 0, (3 * btnW), btnY, btnW, btnH, SWP_NOZORDER | SWP_NOSIZE); //delete unfinished button
		break;
	}
	default: return DefWindowProc(hwnd, msg, wparam, lparam);
	}
	return 0;
}
